package players;

public class HumanPlayer extends Player {
    @Override
    public void makeMove() {
        System.out.println("Se realizó un movimiento.");
    }
}
